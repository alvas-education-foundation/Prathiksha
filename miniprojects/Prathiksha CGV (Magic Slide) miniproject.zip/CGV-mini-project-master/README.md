# CGV-mini-project
cgv mini project magical board
